# bandabi/config.py

from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class ExperimentSpec:
    exp_name: str
    param_path: str
    values: list[Any]   # ✅ float 고정 금지

def _coerce_value(v: Any) -> Any:
    # YAML에서 none/null/"" 처리
    if v is None:
        return None
    if isinstance(v, str):
        s = v.strip()
        if s.lower() in ("none", "null", ""):
            return None
        # 숫자처럼 생기면 float로
        try:
            return float(s)
        except Exception:
            return s
    # int/float는 그대로
    if isinstance(v, (int, float)):
        return float(v)
    return v

def load_experiment_spec(path: str) -> ExperimentSpec:
    data = load_yaml(path)
    exp_name = str(data.get("exp_name") or "exp")
    param_path = str(data.get("param_path") or "")
    values = data.get("values")
    if not param_path:
        raise ConfigError(f"Missing 'param_path' in sweep config: {path}")
    if not isinstance(values, list) or not values:
        raise ConfigError(f"Missing or invalid 'values' in sweep config: {path}")

    vals = [_coerce_value(v) for v in values]   # ✅
    return ExperimentSpec(exp_name=exp_name, param_path=param_path, values=vals)
