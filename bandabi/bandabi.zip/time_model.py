"""Time model.

MVP travel time model using haversine distance with:
- detour_factor (to emulate road detours)
- speed_multiplier (sweep parameter)
- stochastic noise for actual travel times

The interface is intentionally small:
- mean_travel_min(...): deterministic expectation
- sample_travel_min(...): stochastic sample for simulation
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .config import ConfigError


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in km."""
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


@dataclass
class TimeModel:
    """Simple stochastic travel-time model."""

    default_speed_kmh: float
    speed_multiplier: float
    detour_factor: float
    noise_sigma: float
    rng: np.random.Generator

    def mean_travel_min(self, a_lat: float, a_lon: float, b_lat: float, b_lon: float) -> float:
        dist_km = haversine_km(a_lat, a_lon, b_lat, b_lon) * self.detour_factor
        speed = max(1e-6, self.default_speed_kmh * self.speed_multiplier)
        return (dist_km / speed) * 60.0

    def sample_travel_min(self, a_lat: float, a_lon: float, b_lat: float, b_lon: float) -> float:
        mu = self.mean_travel_min(a_lat, a_lon, b_lat, b_lon)
        if self.noise_sigma <= 0:
            return float(mu)

        # lognormal multiplicative noise. E[noise] ~= 1 when mean=-0.5*sigma^2
        noise = self.rng.lognormal(mean=-0.5 * self.noise_sigma**2, sigma=self.noise_sigma)
        return float(max(0.0, mu * noise))


def build_time_model(cfg: dict) -> TimeModel:
    """Build a TimeModel from config."""
    try:
        base = cfg["time_model"]
        sim = cfg["sim"]
    except KeyError as e:
        raise ConfigError(f"Missing config section: {e}") from e

    default_speed_kmh = float(base["default_speed_kmh"])
    speed_multiplier = float(base.get("speed_multiplier", 1.0))
    detour_factor = float(sim.get("detour_factor", 1.0))
    noise_sigma = float(sim.get("travel_time_noise_sigma", 0.0))

    seed = int(sim.get("rng_seed", 123))
    rng = np.random.default_rng(seed)

    return TimeModel(
        default_speed_kmh=default_speed_kmh,
        speed_multiplier=speed_multiplier,
        detour_factor=detour_factor,
        noise_sigma=noise_sigma,
        rng=rng,
    )
