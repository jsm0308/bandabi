"""Command-line entrypoints.

Primary command:
- Run a sweep experiment and write a run folder with leaderboard + variants.

Example:
    python -m bandabi.cli \
        --base configs/base.yaml \
        --scenario configs/scenarios/seoul_allgu_v1.yaml \
        --sweep configs/sweeps/phase1_time_mult.yaml

This produces:
    runs/<exp_name>_<timestamp>/leaderboard.csv
    runs/<exp_name>_<timestamp>/v_1.00/...
"""

from __future__ import annotations

import argparse
import os
from copy import deepcopy
from typing import List

import pandas as pd

from .config import deep_set, load_experiment_spec, load_yaml, merge_dicts, now_tag, save_yaml
from .pipeline import run as run_pipeline


LEADERBOARD_KEY_COLS = [
    "variant",
    "param_path",
    "param_value",
    "pickup_late_mean",
    "pickup_late_p95",
    "pickup_on_time_rate",
    "center_late_mean",
    "center_late_p95",
    "center_on_time_rate",
    "ride_time_mean",
    "ride_time_p95",
    "vehicles_used",
    "total_travel_time",
    "runtime_total_sec",
    "pickup_late_max",
    "center_late_max",
    "ride_time_max",
    "total_travel_time_min",
]


def _fmt_variant_id(v: float) -> str:
    # keep backward compatibility with existing runs like v_0.90
    return f"v_{v:.2f}"


def main(argv: List[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="bandabi-run", description="Run Bandabi simulation sweeps")
    p.add_argument("--base", default="configs/base.yaml", help="Base config YAML")
    p.add_argument("--scenario", default="configs/scenarios/seoul_allgu_v1.yaml", help="Scenario override YAML")
    p.add_argument("--sweep", default="configs/sweeps/phase1_time_mult.yaml", help="Sweep config YAML")
    p.add_argument("--exp-tag", default=None, help="Override experiment folder name")
    args = p.parse_args(argv)

    base = load_yaml(args.base)
    scen = load_yaml(args.scenario)
    sweep = load_experiment_spec(args.sweep)

    cfg0 = merge_dicts(base, scen)

    run_root = cfg0.get("paths", {}).get("run_root", "runs")
    exp_tag = args.exp_tag or f"{sweep.exp_name}_{now_tag()}"
    exp_dir = os.path.join(run_root, exp_tag)
    os.makedirs(exp_dir, exist_ok=True)

    rows = []
    for v in sweep.values:
        cfg = deepcopy(cfg0)
        deep_set(cfg, sweep.param_path, v)

        var_id = _fmt_variant_id(v)
        out_dir = os.path.join(exp_dir, var_id)
        os.makedirs(out_dir, exist_ok=True)

        save_yaml(cfg, os.path.join(out_dir, "config_resolved.yaml"))

        kpis = run_pipeline(cfg, out_dir)
        kpis["variant"] = var_id
        kpis["param_path"] = sweep.param_path
        kpis["param_value"] = float(v)
        rows.append(kpis)

    lb = pd.DataFrame(rows)

    # Ensure stable column ordering for UI/analysis
    for c in LEADERBOARD_KEY_COLS:
        if c not in lb.columns:
            lb[c] = None
    lb = lb[LEADERBOARD_KEY_COLS + [c for c in lb.columns if c not in LEADERBOARD_KEY_COLS]]

    lb.to_csv(os.path.join(exp_dir, "leaderboard.csv"), index=False, encoding="utf-8-sig")

    print(f"[DONE] {os.path.join(exp_dir, 'leaderboard.csv')} 생성 완료")


if __name__ == "__main__":
    main()
