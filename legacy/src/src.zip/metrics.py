"""Compatibility re-export for KPIs (migrated to bandabi.metrics)."""

from bandabi.metrics import compute_kpis

__all__ = ["compute_kpis"]
