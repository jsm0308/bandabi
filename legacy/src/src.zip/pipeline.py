"""Compatibility re-export for pipeline (migrated to bandabi.pipeline)."""

from bandabi.pipeline import run

__all__ = ["run"]
