"""Legacy entrypoint.

Use:
    python -m bandabi.cli ...

This file exists so old commands like `python -m src.runner` still work.
"""

from bandabi.cli import main


if __name__ == "__main__":
    main()
